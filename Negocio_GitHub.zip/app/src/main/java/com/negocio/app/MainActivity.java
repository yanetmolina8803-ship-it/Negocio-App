package com.negocio.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root, list;
    TextView totalView;
    int red=0xFFE51E3A, pink=0xFFFFE4EA, dark=0xFF303030;
    NumberFormat money=NumberFormat.getNumberInstance(new Locale("es","US"));

    @Override public void onCreate(Bundle b){ super.onCreate(b); db=new DB(this); showHome(); }
    TextView text(String s,int size, boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(dark);
        if(bold)t.setTypeface(null, Typeface.BOLD); t.setPadding(8,8,8,8); return t;
    }
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    void base(String title){
        ScrollView sc=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1);
        root.setPadding(16,16,16,24); root.setBackgroundColor(0xFFFFF8F9); sc.addView(root); setContentView(sc);
        TextView h=text(title,25,true); h.setTextColor(red); root.addView(h);
    }
    void showHome(){
        base("Negocio");
        root.addView(text("Registro de compras",17,false));
        Button add=button("+ Nueva compra"); add.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red)); add.setTextColor(-1);
        root.addView(add); add.setOnClickListener(v->newPurchase());
        totalView=text("",19,true); root.addView(totalView);
        refresh();
        root.addView(text("Historial de compras",20,true));
        list=new LinearLayout(this); list.setOrientation(1); root.addView(list); loadPurchases();
    }
    void refresh(){ totalView.setText("Total gastado: $"+fmt(db.grandTotal())); }
    String fmt(double v){ return String.format(Locale.US,"%,.2f",v); }
    void loadPurchases(){
        list.removeAllViews();
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id, purchase_date, total FROM purchases ORDER BY id DESC",null);
        if(c.getCount()==0) list.addView(text("Todavía no hay compras guardadas.",16,false));
        while(c.moveToNext()){
            int id=c.getInt(0); String date=c.getString(1); double total=c.getDouble(2);
            LinearLayout card=new LinearLayout(this); card.setOrientation(1); card.setPadding(12,10,12,10); card.setBackgroundColor(pink);
            TextView label=text(date+"   •   $"+fmt(total),17,true); card.addView(label);
            Button detail=button("Ver / editar productos"); card.addView(detail); detail.setOnClickListener(v->showPurchase(id,date));
            Button del=button("Eliminar compra"); card.addView(del); del.setOnClickListener(v->confirmDelete(id));
            list.addView(card);
        } c.close();
    }
    void newPurchase(){
        EditText date=new EditText(this); date.setHint("Fecha (ej. 29/10/2026)");
        date.setText(new java.text.SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new java.util.Date()));
        new AlertDialog.Builder(this).setTitle("Nueva compra").setView(date)
          .setNegativeButton("Cancelar",null).setPositiveButton("Crear",(d,w)->{
            long id=db.createPurchase(date.getText().toString().trim()); showPurchase((int)id,date.getText().toString().trim());
          }).show();
    }
    void showPurchase(int id,String date){
        base("Compra • "+date);
        root.addView(text("Agrega todos los productos que forman parte de esta compra.",15,false));
        Button add=button("+ Agregar producto"); root.addView(add); add.setOnClickListener(v->addProduct(id,date));
        TextView sum=text("",20,true); root.addView(sum);
        LinearLayout items=new LinearLayout(this); items.setOrientation(1); root.addView(items);
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,quantity,unit,price FROM products WHERE purchase_id=? ORDER BY id",new String[]{""+id});
        while(c.moveToNext()){
            int pid=c.getInt(0); String name=c.getString(1); double qty=c.getDouble(2); String unit=c.getString(3); double price=c.getDouble(4);
            LinearLayout row=new LinearLayout(this); row.setOrientation(1); row.setPadding(10,8,10,8); row.setBackgroundColor(pink);
            row.addView(text(name+"  •  "+fmt(qty)+" "+unit,17,true));
            row.addView(text("Precio unitario: $"+fmt(price)+"   |   Importe: $"+fmt(qty*price),15,false));
            Button edit=button("Editar"); row.addView(edit); edit.setOnClickListener(v->editProduct(id,pid,date));
            Button del=button("Eliminar"); row.addView(del); del.setOnClickListener(v->{db.deleteProduct(pid); showPurchase(id,date);});
            items.addView(row);
        } c.close();
        double sumVal=db.purchaseTotal(id); sum.setText("Total de esta compra: $"+fmt(sumVal));
        Button back=button("Volver al historial"); root.addView(back); back.setOnClickListener(v->showHome());
    }
    void addProduct(int purchase,String date){ productDialog(purchase,-1,date); }
    void editProduct(int purchase,int product,String date){ productDialog(purchase,product,date); }
    void productDialog(int purchase,int product,String date){
        LinearLayout form=new LinearLayout(this); form.setOrientation(1); form.setPadding(20,4,20,4);
        EditText name=field("Nombre del producto"), qty=field("Cantidad"), unit=field("Unidad (sacos, libras, unidades...)"), price=field("Precio por unidad");
        form.addView(name); form.addView(qty); form.addView(unit); form.addView(price);
        if(product!=-1){
            Cursor c=db.getReadableDatabase().rawQuery("SELECT name,quantity,unit,price FROM products WHERE id=?",new String[]{""+product});
            if(c.moveToFirst()){name.setText(c.getString(0));qty.setText(""+c.getDouble(1));unit.setText(c.getString(2));price.setText(""+c.getDouble(3));} c.close();
        }
        new AlertDialog.Builder(this).setTitle(product==-1?"Agregar producto":"Editar producto").setView(form)
          .setNegativeButton("Cancelar",null).setPositiveButton("Guardar",(d,w)->{
            try{
                String n=name.getText().toString().trim(), u=unit.getText().toString().trim();
                double q=Double.parseDouble(qty.getText().toString().replace(',','.'));
                double p=Double.parseDouble(price.getText().toString().replace(',','.'));
                if(n.isEmpty()||u.isEmpty()||q<=0||p<0) throw new Exception();
                if(product==-1) db.addProduct(purchase,n,q,u,p); else db.updateProduct(product,n,q,u,p);
                showPurchase(purchase,date);
            }catch(Exception e){new AlertDialog.Builder(this).setMessage("Revisa los datos: nombre, cantidad y precio deben ser válidos.").setPositiveButton("Aceptar",null).show();}
          }).show();
    }
    EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); return e; }
    void confirmDelete(int id){
        new AlertDialog.Builder(this).setMessage("¿Eliminar esta compra y todos sus productos?")
        .setNegativeButton("Cancelar",null).setPositiveButton("Eliminar",(d,w)->{db.deletePurchase(id);showHome();}).show();
    }

    class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"negocio.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,purchase_date TEXT NOT NULL,total REAL DEFAULT 0)");
            d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,purchase_id INTEGER NOT NULL,name TEXT NOT NULL,quantity REAL NOT NULL,unit TEXT NOT NULL,price REAL NOT NULL)");
        }
        public void onUpgrade(SQLiteDatabase d,int a,int b){}
        long createPurchase(String date){android.content.ContentValues v=new android.content.ContentValues();v.put("purchase_date",date);return getWritableDatabase().insert("purchases",null,v);}
        void addProduct(int id,String n,double q,String u,double p){android.content.ContentValues v=new android.content.ContentValues();v.put("purchase_id",id);v.put("name",n);v.put("quantity",q);v.put("unit",u);v.put("price",p);getWritableDatabase().insert("products",null,v);updateTotal(id);}
        void updateProduct(int id,String n,double q,String u,double p){Cursor c=getReadableDatabase().rawQuery("SELECT purchase_id FROM products WHERE id=?",new String[]{""+id});int purchase=-1;if(c.moveToFirst())purchase=c.getInt(0);c.close();android.content.ContentValues v=new android.content.ContentValues();v.put("name",n);v.put("quantity",q);v.put("unit",u);v.put("price",p);getWritableDatabase().update("products",v,"id=?",new String[]{""+id});if(purchase!=-1)updateTotal(purchase);}
        void deleteProduct(int id){Cursor c=getReadableDatabase().rawQuery("SELECT purchase_id FROM products WHERE id=?",new String[]{""+id});int purchase=-1;if(c.moveToFirst())purchase=c.getInt(0);c.close();getWritableDatabase().delete("products","id=?",new String[]{""+id});if(purchase!=-1)updateTotal(purchase);}
        void deletePurchase(int id){getWritableDatabase().delete("products","purchase_id=?",new String[]{""+id});getWritableDatabase().delete("purchases","id=?",new String[]{""+id});}
        double purchaseTotal(int id){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(quantity*price),0) FROM products WHERE purchase_id=?",new String[]{""+id});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
        double grandTotal(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(quantity*price),0) FROM products",null);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
        void updateTotal(int id){android.content.ContentValues v=new android.content.ContentValues();v.put("total",purchaseTotal(id));getWritableDatabase().update("purchases",v,"id=?",new String[]{""+id});}
    }
}
