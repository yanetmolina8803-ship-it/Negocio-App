# Negocio

Aplicación Android para registrar compras con varios productos por compra.

## Funciones incluidas
- Crear compras con fecha.
- Agregar varios productos a cada compra.
- Nombre, cantidad, unidad de medida y precio por unidad.
- Cálculo automático del importe por producto y total de compra.
- Historial de compras y total acumulado.
- Editar y eliminar productos y compras.
- Datos guardados localmente en SQLite; funciona sin conexión.

## Crear APK
El proyecto usa Android Gradle Plugin 8.7.3 y compileSdk 35. Abre el proyecto en Android Studio y ejecuta `assembleDebug`.
La APK de prueba se genera en `app/build/outputs/apk/debug/app-debug.apk`.
