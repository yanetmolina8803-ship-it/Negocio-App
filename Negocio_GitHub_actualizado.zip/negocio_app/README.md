# Negocio - Android
Interfaz rosado tierno. Pestañas Inicio, Inversión e Historial. Compras por fecha con varios productos en tabla: cada producto es una fila y cada detalle una columna. Se introducen manualmente cantidad, unidad de compra, contenido por paquete, unidad de contenido, costo por paquete y precio de venta. El costo unitario se calcula como costo del paquete dividido entre contenido. Total de compra = cantidad de paquetes por costo de paquete. Datos locales SQLite y uso sin conexión.

Compilar con `gradle assembleDebug`. APK: `app/build/outputs/apk/debug/app-debug.apk`.
